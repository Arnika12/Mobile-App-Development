package com.example.datetime;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnDatePicker , btnTimePicker;
    EditText textDate , textTime;
    private int mYear, mMonth, mDay, nHour, mMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnDatePicker = (Button)  findViewById(R.id.dbutton);
        btnTimePicker = (Button)  findViewById(R.id.tbutton);
        textDate = (EditText)  findViewById(R.id.datetext);
        textTime = (EditText)  findViewById(R.id.timetext);

        btnDatePicker.setOnClickListener(this);
        btnTimePicker.setOnClickListener(this);
    }

    public void onClick(View v){
        if(v == btnDatePicker){

            //Get current date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datepd = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthofyear, int dayofmonth) {
                    textDate.setText(dayofmonth + "." + (monthofyear +1) + "."+ year);
                }
            },mYear , mMonth , mDay);
        datepd.show();
        }

        if(v == btnTimePicker){

            //set current time
            final Calendar c = Calendar.getInstance();
            nHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            TimePickerDialog timepd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourofday, int minute) {
                    textTime.setText(hourofday + ":" + minute);
                }
            },nHour , mMinute , false);
        timepd.show();
        }
    }
}