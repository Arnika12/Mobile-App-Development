package com.example.sqlite;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText name , age , ID ;
    TextView viewusers;
    Button addbutton, updatebutton, deletebutton, viewallbutton ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        name = findViewById(R.id.name);
        age = findViewById(R.id.age);
        ID = findViewById(R.id.ID);
        viewusers = findViewById(R.id.viewusers);

        addbutton = findViewById(R.id.buttonadd);
        updatebutton = findViewById(R.id.buttonupdate);
        deletebutton = findViewById(R.id.buttondelete);
        viewallbutton = findViewById(R.id.buttonviewall);

        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addUser();
            }
        });

        updatebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateUser();
            }
        });

        deletebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteUser();
            }
        });

        viewallbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getAllUsers();
            }
        });
    }

    private void addUser(){
        String ename = name.getText().toString();
        int eage = Integer.parseInt(age.getText().toString());

        long eid = databaseHelper.addUser(ename , eage);
        if(eid > 0){
            Toast.makeText(this, "User Added", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "ERROR Adding User", Toast.LENGTH_SHORT).show();
        }
    }

    private void getAllUsers(){
        Cursor cursor = databaseHelper.getAllUsers();
        if(cursor.getCount() == 0){
            viewusers.setText("No Users Found !!");
            return;
        }

        StringBuilder stringBuilder = new StringBuilder();
        while(cursor.moveToNext()){
            stringBuilder.append("ID : ").append(cursor.getInt(0)).append("\n");
            stringBuilder.append("NAME : ").append(cursor.getInt(1)).append("\n");
            stringBuilder.append("AGE : ").append(cursor.getInt(2)).append("\n");
        }

        viewusers.setText(stringBuilder.toString());
    }

    private void updateUser(){
        int eid = Integer.parseInt(ID.getText().toString());
        String ename = name.getText().toString();
        int eage = Integer.parseInt(age.getText().toString());

        int result = databaseHelper.updateUser(eid , ename , eage);
        if(result > 0){
            Toast.makeText(this, "User Updated", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "ERROR Updating User", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteUser(){
        int eid = Integer.parseInt(ID.getText().toString());
        databaseHelper.deleteUser(eid);
        Toast.makeText(this, "User Deleted", Toast.LENGTH_SHORT).show();
    }
}