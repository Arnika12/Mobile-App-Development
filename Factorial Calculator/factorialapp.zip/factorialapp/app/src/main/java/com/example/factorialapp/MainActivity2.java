package com.example.factorialapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    TextView tview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        tview = (TextView) findViewById(R.id.t2);
        Intent i = getIntent();
        String rvalue = i.getStringExtra("KEY_SENDER");
        tview.setText(rvalue);
    }
}