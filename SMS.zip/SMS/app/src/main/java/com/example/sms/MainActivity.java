package com.example.sms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText phonenumber,message;
    Button sendSMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phonenumber=findViewById(R.id.mno);
        message=findViewById(R.id.msg);
        sendSMS=findViewById(R.id.button);

        sendSMS.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    SmsManager smsManager=SmsManager.getDefault();
                    smsManager.sendTextMessage(phonenumber.getText().toString(),null,message.getText().toString(),null,null);
                    Toast.makeText(MainActivity.this,"Message Sent Successfully.",Toast.LENGTH_SHORT).show();
                }catch (Exception e)
                {
                    Toast.makeText(MainActivity.this,"Failed to sent",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
