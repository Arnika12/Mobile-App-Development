package com.example.unconverter;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button b1;
    private TextView textView3;
    private EditText number1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.button);
        textView3 = findViewById(R.id.textView3);
        number1 = findViewById(R.id.number1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = number1.getText().toString();
                if (s.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a value", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int kg = Integer.parseInt(s);
                    double pound = 2.205 * kg;
                    textView3.setText("The corresponding value in pounds is " + pound);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Invalid input. Please enter a number.", Toast.LENGTH_SHORT).show();
                }

//                Toast.makeText(MainActivity.this, "onclick activated", Toast.LENGTH_SHORT).show();
//                String s = number1.getText().toString();
//                int kg = Integer.parseInt(s);
//                double pound = 2.205 * kg;
//                textView3.setText("The corresponding value in pounds is "+ pound);
            }
        });
    }
}