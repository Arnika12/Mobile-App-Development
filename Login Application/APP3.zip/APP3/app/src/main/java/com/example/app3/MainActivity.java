package com.example.app3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText TextUserName, TextPassword;
    Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextUserName = findViewById(R.id.uname);
        TextPassword = findViewById(R.id.pass);
        loginButton = findViewById(R.id.button);

        loginButton.setOnClickListener(view -> {
            String username = TextUserName.getText().toString();
            String password = TextPassword.getText().toString();

            if (username.equals("Admin") && password.equals("admin")) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("username", username);
                intent.putExtra("password", password);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
