package com.example.avg_pow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText n1, n2;
    Button b1;

    private int calculateAvg(int numb1, int numb2) {
        int sum = numb1 + numb2;
        return sum / 2;
    }

    private double calculatePow(int numb1, int numb2) {
        return Math.pow(numb1, numb2);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        n1 = findViewById(R.id.num1);
        n2 = findViewById(R.id.num2);
        b1 = findViewById(R.id.button);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String num1Text = n1.getText().toString();
                String num2Text = n2.getText().toString();

                if (num1Text.isEmpty() || num2Text.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
                    return;
                }

                int num1 = Integer.parseInt(num1Text);
                int num2 = Integer.parseInt(num2Text);

                int avg = calculateAvg(num1, num2);
                double pow = calculatePow(num1, num2);

                Intent i = new Intent(MainActivity.this, MainActivity2.class);
                i.putExtra("KEY_NUM1", num1);
                i.putExtra("KEY_NUM2", num2);
                i.putExtra("KEY_AVG", avg);
                i.putExtra("KEY_POW", pow);
                startActivity(i);
            }
        });
    }
}
