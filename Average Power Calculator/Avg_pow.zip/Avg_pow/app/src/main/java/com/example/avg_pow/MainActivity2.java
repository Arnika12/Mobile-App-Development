package com.example.avg_pow;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    TextView text1, text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        text1 = findViewById(R.id.t1);
        text2 = findViewById(R.id.t2);

        Intent i = getIntent();
        int num1 = i.getIntExtra("KEY_NUM1", 0);
        int num2 = i.getIntExtra("KEY_NUM2", 0);
        int avg = i.getIntExtra("KEY_AVG", 0);
        double pow = i.getDoubleExtra("KEY_POW", 0.0);

        text1.setText("Given Numbers: " + num1 + " and " + num2);
        text2.setText("Average: " + avg + "\nPower: " + pow);
    }
}
