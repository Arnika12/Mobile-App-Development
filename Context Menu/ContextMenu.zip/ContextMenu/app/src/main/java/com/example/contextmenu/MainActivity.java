package com.example.contextmenu;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button b = (Button)  findViewById(R.id.btnshow);
        registerForContextMenu(b);
    }

    @Override
    public void onCreateContextMenu(ContextMenu cmenu, View v, ContextMenu.ContextMenuInfo cminfo){
        super.onCreateContextMenu(cmenu, v, cminfo);
        cmenu.setHeaderTitle("Context Menu");
        cmenu.add(0, v.getId(), 0, "Upload");
        cmenu.add(0, v.getId(), 0, "Search");
        cmenu.add(0, v.getId(), 0, "Share");
        cmenu.add(0, v.getId(), 0, "Bookmark");
    }

    @Override
    public boolean onContextItemSelected(MenuItem mitem){
        Toast.makeText(this, "You Selected : " + mitem.getTitle(), Toast.LENGTH_SHORT).show();
        return true;
    }
}