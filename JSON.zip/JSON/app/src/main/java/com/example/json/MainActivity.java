package com.example.json;

import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    String JSON_STRING = "{\"employee\":{\"name\":\"Arnika\",\"salary\":68000}}";
    TextView empname, empsalary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        empname = findViewById(R.id.ename);
        empsalary = findViewById(R.id.esal);

        try {
            JSONObject emp = new JSONObject(JSON_STRING);
            JSONObject employee = emp.getJSONObject("employee");

            String name = employee.getString("name");
            String salary = employee.getString("salary");

            empname.setText(name);
            empsalary.setText(salary);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
