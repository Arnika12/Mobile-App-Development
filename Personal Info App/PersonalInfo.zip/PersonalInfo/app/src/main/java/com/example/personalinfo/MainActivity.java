package com.example.personalinfo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText FirstName,MiddleName,LastName,DOB,Address,Email;
    Button SubmitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        FirstName = findViewById(R.id.fname);
        MiddleName = findViewById(R.id.mname);
        LastName = findViewById(R.id.lname);
        DOB = findViewById(R.id.DOB);
        Address = findViewById(R.id.add);
        Email = findViewById(R.id.email);
        SubmitButton = findViewById(R.id.button);

        SubmitButton.setOnClickListener(view -> {
            String first = FirstName.getText().toString();
            String middle = MiddleName.getText().toString();
            String last = LastName.getText().toString();
            String dateOB = DOB.getText().toString();
            String address = Address.getText().toString();
            String emailid = Email.getText().toString();

            if (first.isEmpty() || last.isEmpty() || dateOB.isEmpty() || address.isEmpty() || emailid.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill out all required fields", Toast.LENGTH_SHORT).show();
            } else {
                Intent i = new Intent(MainActivity.this, MainActivity2.class);
                Bundle bundle = new Bundle();
                bundle.putString("fname", first);
                bundle.putString("mname", middle);
                bundle.putString("lname", last);
                bundle.putString("dob", dateOB);
                bundle.putString("addr", address);
                bundle.putString("email", emailid);

                i.putExtras(bundle);

                startActivity(i);
            }
        });
    }
}