package com.example.personalinfo;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    TextView DisplayFName,DisplayMName,DisplayLName, DisplayDOB, DisplayAddress, DisplayEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // Initialize TextViews
        DisplayFName = findViewById(R.id.t1);
        DisplayMName = findViewById(R.id.t2);
        DisplayLName = findViewById(R.id.t3);
        DisplayDOB = findViewById(R.id.t4);
        DisplayAddress = findViewById(R.id.t5);
        DisplayEmail = findViewById(R.id.t6);

        // Retrieve data from the Intent
        String firstName = getIntent().getStringExtra("fname");
        String middleName = getIntent().getStringExtra("mname");
        String lastName = getIntent().getStringExtra("lname");
        String dob = getIntent().getStringExtra("dob");
        String address = getIntent().getStringExtra("addr");
        String email = getIntent().getStringExtra("email");

        // Display data
        DisplayFName.setText("First Name is "+ firstName);
        DisplayMName.setText("Middle Name is "+middleName);
        DisplayLName.setText("Last Name is "+lastName);
        DisplayDOB.setText("Date of Birth is "+dob);
        DisplayAddress.setText("Address is "+address);
        DisplayEmail.setText("Email id is "+email);
    }
}